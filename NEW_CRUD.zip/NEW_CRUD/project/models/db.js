const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://soundarraj:Q7DGjkul8lQyjJ3t@demo1.e42mt.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', { useNewUrlParser: true }, (err) => {
    if (!err) { console.log('MongoDB Connection Succeeded.') }
    else { console.log('Error in DB connection : ' + err) }
});

require('./employee.model');

// const { MongoClient } = require('mongodb');
// const uri = "mongodb+srv://soundarraj:Q7DGjkul8lQyjJ3t@demo1.e42mt.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
// const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
// client.connect(err => {
//   console.log('err',err);
//   // client.close();
// });